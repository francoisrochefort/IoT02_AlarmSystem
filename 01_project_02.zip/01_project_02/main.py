from tkinter import *
from mainwindow import MainWindow


def main():
    main = MainWindow(master=Tk())
    main.mainloop()


if __name__ == '__main__':
    main()
