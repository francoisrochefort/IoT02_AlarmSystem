from tkinter import *
from eventlog import EventLog


# history window
class HistoryWindow(Frame):

    # event handlers
    def on_destroy_window(self):
        self.master.destroy()

    # class constructor
    def __init__(self, master=None):

        # init. window
        super().__init__(master) 
        self.master = master
        self.master.title("History")
        self.master.geometry("400x225")
        self.master.protocol("WM_DELETE_WINDOW", lambda: self.on_destroy_window())
        self.pack()

        # create a text widget
        self.txt = Text(self)

        # insert all event logs to the text widget
        event_log: EventLog = EventLog()
        for event in event_log.get_event_logs():
            self.txt.insert(INSERT, f"{event['date']} \t {event['time']} \t {event['object']} \t {event['event']}\n")
        self.txt.pack(anchor=W)
        
        # free unused object
        del event_log
